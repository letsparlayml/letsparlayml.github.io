async function loadJson(path, fallback = null) {
  try {
    const res = await fetch(path, { cache: 'no-store' });
    if (!res.ok) throw new Error(`Failed to load ${path}`);
    return await res.json();
  } catch (err) {
    if (fallback !== null) return fallback;
    throw err;
  }
}


async function loadText(path, fallback = '') {
  try {
    const res = await fetch(path, { cache: 'no-store' });
    if (!res.ok) throw new Error(`Failed to load ${path}`);
    return await res.text();
  } catch (err) {
    return fallback;
  }
}

function byId(id) {
  return document.getElementById(id);
}

function propDateValue(prop) {
  return prop?.gameDate || prop?.date || prop?.propDate || prop?.game_date || '';
}

function filterPropsByDate(props, date) {
  if (!date) return props || [];
  const dated = (props || []).filter(p => propDateValue(p));
  if (!dated.length) return props || [];
  return dated.filter(p => propDateValue(p) === date);
}

function hasNumericValue(v) {
  return v !== null && v !== undefined && v !== '' && Number.isFinite(Number(v));
}

function setText(id, value) {
  const el = byId(id);
  if (el) el.textContent = value ?? '';
}

function normalizeSearchText(value) {
  return String(value || '').toLowerCase().replace(/\s+/g, ' ').trim();
}

function uniqueSortedDates(rows) {
  return Array.from(new Set((rows || []).map(row => String(row?.date || '').trim()).filter(Boolean)))
    .sort((a, b) => b.localeCompare(a));
}

function dedupeRowsByKey(rows, keyFn) {
  const seen = new Map();
  (rows || []).forEach(row => {
    const key = keyFn(row);
    if (key) seen.set(key, row);
  });
  return Array.from(seen.values());
}

function populateDateSelect(select, dates, preferredDate = '', allLabel = 'All dates') {
  if (!select) return;
  const wanted = String(preferredDate || '').trim();
  const options = ['__ALL__', ...dates];
  select.innerHTML = options.map(value => {
    const label = value === '__ALL__' ? allLabel : value;
    return `<option value="${escapeHtml(value)}">${escapeHtml(label)}</option>`;
  }).join('');
  if (wanted && options.includes(wanted)) select.value = wanted;
  else select.value = dates[0] || '__ALL__';
}

function filterRowsByDate(rows, selectedDate) {
  const wanted = String(selectedDate || '').trim();
  if (!wanted || wanted === '__ALL__') return (rows || []).slice();
  return (rows || []).filter(row => String(row?.date || '') === wanted);
}

function currentDateLabel(selectedDate, fallbackLabel = 'All dates') {
  const wanted = String(selectedDate || '').trim();
  return wanted && wanted !== '__ALL__' ? wanted : fallbackLabel;
}

function isNbaGame(game) {
  return String(game?.league || '').toUpperCase() === 'NBA';
}

function modelSpreadForDisplay(game) {
  if (isNbaGame(game)) {
    const away = Number(game?.modelAwayScore);
    const home = Number(game?.modelHomeScore);
    if (Number.isFinite(away) && Number.isFinite(home)) {
      // NBA cards should display spread from AWAY-team perspective
      return home - away;
    }

    const fallback = Number(game?.modelHomeSpread);
    return Number.isFinite(fallback) ? -fallback : NaN;
  }

  // CBB/NHL: keep existing stored convention
  const stored = Number(game?.modelHomeSpread);
  return Number.isFinite(stored) ? stored : NaN;
}

function marketSpreadForDisplay(game) {
  const spread = Number(game?.marketSpread);
  if (!Number.isFinite(spread)) return NaN;
  return spread;
}

function spreadEdgeForDisplay(game) {
  const model = modelSpreadForDisplay(game);
  const market = marketSpreadForDisplay(game);
  return Number.isFinite(model) && Number.isFinite(market)
    ? model - market
    : NaN;
}

function spreadTeamLabel(game, awaySpread) {
  if (!Number.isFinite(awaySpread)) return 'N/A';
  if (Math.abs(awaySpread) < 0.05) return 'PK';
  return awaySpread > 0
    ? `${game?.homeTeam || 'Home'} ${fmtSigned(-awaySpread)}`
    : `${game?.awayTeam || 'Away'} ${fmtSigned(awaySpread)}`;
}

function spreadEdgeText(game) {
  const edge = spreadEdgeForDisplay(game);
  if (!Number.isFinite(edge)) return 'N/A';
  if (Math.abs(edge) < 0.05) return 'PK';
  const leanTeam = edge > 0 ? (game?.homeTeam || 'Home') : (game?.awayTeam || 'Away');
  return `${leanTeam} ${Math.abs(edge).toFixed(1)} pts`;
}

function marketSpreadText(game) {
  const spread = marketSpreadForDisplay(game);
  return spreadTeamLabel(game, spread);
}

function modelSpreadText(game) {
  const spread = modelSpreadForDisplay(game);
  return spreadTeamLabel(game, spread);
}

function cardSummaryText(game) {
  const raw = String(game?.summary || 'Model snapshot');
  const spread = marketSpreadForDisplay(game);
  const total = Number(game?.marketTotal);

  return raw
    .replace(
      /Spread line pending/g,
      Number.isFinite(spread) ? `Spread line ${spreadTeamLabel(game, spread)}` : 'Spread line pending'
    )
    .replace(
      /Total line pending/g,
      Number.isFinite(total) ? `Total line ${fmt(total)}` : 'Total line pending'
    );
}

function derivedSpreadProbabilityForDisplay(game, edge) {
  const league = String(game?.league || '').toUpperCase();
  const scale = league === 'NBA' ? 0.018 : league === 'NHL' ? 0.075 : 0.060;
  const cap = league === 'NBA' ? 0.67 : 0.68;
  return Math.min(cap, 0.50 + Math.abs(edge) * scale);
}

function derivedTotalProbabilityForDisplay(game, gap) {
  const league = String(game?.league || '').toUpperCase();
  const scale = league === 'NBA' ? 0.012 : league === 'NHL' ? 0.055 : 0.035;
  const cap = league === 'NBA' ? 0.70 : 0.67;
  return Math.min(cap, 0.52 + Math.abs(gap) * scale);
}

function signedLineText(team, line) {
  return `${team || 'Team'} ${fmtSigned(line, 1)}`;
}

function mlbMarketRunLineSignal(game) {
  const spread = marketSpreadForDisplay(game);
  if (!Number.isFinite(spread) || Math.abs(Math.abs(spread) - 1.5) > 0.11) return '';

  let candidates = [];
  if (spread > 0) {
    // Away +1.5 / home -1.5. Show whichever side the model makes more likely.
    candidates = [
      { label: `${game?.homeTeam || 'Home'} -1.5`, prob: coerceProbability(game?.homeMinus1p5Prob) },
      { label: `${game?.awayTeam || 'Away'} +1.5`, prob: coerceProbability(game?.awayPlus1p5Prob) },
    ];
  } else {
    // Away -1.5 / home +1.5. Show whichever side the model makes more likely.
    candidates = [
      { label: `${game?.awayTeam || 'Away'} -1.5`, prob: coerceProbability(game?.awayMinus1p5Prob) },
      { label: `${game?.homeTeam || 'Home'} +1.5`, prob: coerceProbability(game?.homePlus1p5Prob) },
    ];
  }

  const best = candidates
    .filter(item => Number.isFinite(item.prob))
    .sort((a, b) => b.prob - a.prob)[0];
  return best ? `${best.label} ${fmtPct(best.prob, 0)}` : '';
}

function spreadSignalText(game) {
  const league = String(game?.league || '').toUpperCase();
  const marketSpread = marketSpreadForDisplay(game);
  const storedModelPickProb = coerceProbability(game?.modelSpreadPickProb);
  if (game?.modelSpreadPickLabel && Number.isFinite(storedModelPickProb)) {
    return `${game.modelSpreadPickLabel} ${fmtPct(storedModelPickProb, 0)}`;
  }

  if (league === 'MLB') {
    const mlbSignal = mlbMarketRunLineSignal(game);
    if (mlbSignal) return mlbSignal;
  }

  const modelSpread = modelSpreadForDisplay(game);
  if (Number.isFinite(modelSpread) && Number.isFinite(marketSpread)) {
    const edge = modelSpread - marketSpread;
    const prob = derivedSpreadProbabilityForDisplay(game, edge);
    if (edge >= 0) {
      return `${signedLineText(game?.homeTeam || 'Home', -marketSpread)} ${fmtPct(prob, 0)}`;
    }
    return `${signedLineText(game?.awayTeam || 'Away', marketSpread)} ${fmtPct(prob, 0)}`;
  }

  const marketCoverProb = coerceProbability(game?.marketCoverProb);
  if (game?.marketCoverLabel && Number.isFinite(marketCoverProb)) {
    return `${game.marketCoverLabel} ${fmtPct(marketCoverProb, 0)}`;
  }

  return Number.isFinite(marketSpread) ? `${spreadTeamLabel(game, marketSpread)} prob pending` : 'Spread pending';
}

function totalSignalText(game) {
  const marketTotal = Number(game?.marketTotal);
  const modelTotal = Number(game?.modelTotal);
  const storedTotalProb = coerceProbability(game?.modelTotalPickProb);
  if (game?.modelTotalPickLabel && Number.isFinite(storedTotalProb)) {
    return `${game.modelTotalPickLabel} ${fmtPct(storedTotalProb, 0)}`;
  }

  const over = coerceProbability(game?.marketOverProb);
  const under = coerceProbability(game?.marketUnderProb);

  if (Number.isFinite(marketTotal) && (Number.isFinite(over) || Number.isFinite(under))) {
    if ((Number.isFinite(over) ? over : 0) >= (Number.isFinite(under) ? under : 0)) {
      return `Over ${fmt(marketTotal, 1)} ${fmtPct(over, 0)}`;
    }
    return `Under ${fmt(marketTotal, 1)} ${fmtPct(under, 0)}`;
  }

  if (Number.isFinite(marketTotal) && Number.isFinite(modelTotal)) {
    const gap = modelTotal - marketTotal;
    const side = gap >= 0 ? 'Over' : 'Under';
    const prob = derivedTotalProbabilityForDisplay(game, gap);
    return `${side} ${fmt(marketTotal, 1)} ${fmtPct(prob, 0)}`;
  }

  return Number.isFinite(marketTotal) ? `Total ${fmt(marketTotal, 1)} prob pending` : 'Total pending';
}

function moneylineSignalText(game) {
  const storedProb = coerceProbability(game?.modelMoneylineProb ?? game?.favoriteWinProb);
  const storedLabel = game?.modelMoneylineLabel || game?.favoriteWinLabel || '';
  if (storedLabel && Number.isFinite(storedProb)) {
    return `${storedLabel.replace(/ win$/i, ' ML')} ${fmtPct(storedProb, 0)}`;
  }

  const home = Number(game?.modelHomeScore);
  const away = Number(game?.modelAwayScore);
  if (Number.isFinite(home) && Number.isFinite(away)) {
    const team = home >= away ? (game?.homeTeam || 'Home') : (game?.awayTeam || 'Away');
    return `${team} ML prob pending`;
  }
  return 'ML pending';
}

function gameMarketSignalsHtml(game) {
  return `
    <div class="game-signal-row" aria-label="Model picks for current market lines">
      <span class="game-signal-chip"><b>ML</b> ${escapeHtml(moneylineSignalText(game))}</span>
      <span class="game-signal-chip"><b>Spread</b> ${escapeHtml(spreadSignalText(game))}</span>
      <span class="game-signal-chip"><b>Total</b> ${escapeHtml(totalSignalText(game))}</span>
    </div>
  `;
}

function normalizeLookupToken(value) {
  return String(value ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/\b(jr|sr|ii|iii|iv|v)\b/g, ' ')
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function normalizeTeamToken(value) {
  return String(value ?? '')
    .toUpperCase()
    .replace(/[^A-Z]/g, '')
    .trim();
}

function canonicalInjuryStatus(value) {
  const raw = String(value ?? '').trim().toLowerCase();
  if (!raw) return '';
  const map = {
    p: 'probable',
    probable: 'probable',
    q: 'questionable',
    questionable: 'questionable',
    gtd: 'questionable',
    out: 'out',
    o: 'out',
    doubtful: 'doubtful',
    d: 'doubtful'
  };
  return map[raw] || raw;
}

function titleCaseWord(value) {
  if (!value) return '';
  return String(value).charAt(0).toUpperCase() + String(value).slice(1).toLowerCase();
}

function buildInjuryLookup(injuryData) {
  const lookup = new Map();
  const players = injuryData?.players || injuryData?.entries || [];
  (players || []).forEach(entry => {
    const playerKey = normalizeLookupToken(entry.player || entry.player_name);
    if (!playerKey) return;

    const teamKey = normalizeTeamToken(entry.team || entry.team_abbr);
    const normalized = {
      status: titleCaseWord(canonicalInjuryStatus(entry.status)),
      note: entry.note || entry.injury_note || '',
      team: entry.team || entry.team_abbr || '',
      lastUpdated: entry.lastUpdated || entry.last_updated || entry.updated_at || '',
      gameDate: entry.gameDate || entry.game_date || ''
    };

    if (teamKey) {
      lookup.set(`${playerKey}|${teamKey}`, normalized);
    }

    // Always create a player-only fallback too
    if (!lookup.has(`${playerKey}|`)) {
      lookup.set(`${playerKey}|`, normalized);
    }
  });
  return lookup;
}

function getPropInjuryContext(prop, injuryLookup) {
  if (!injuryLookup || !injuryLookup.size) return null;
  const playerKey = normalizeLookupToken(prop?.player);
  if (!playerKey) return null;
  const teamKey = normalizeTeamToken(prop?.team);
  return injuryLookup.get(`${playerKey}|${teamKey}`) || injuryLookup.get(`${playerKey}|`) || null;
}

function decoratePropInjury(prop, injuryLookup) {
  const context = getPropInjuryContext(prop, injuryLookup);
  if (!context) return { ...prop };
  return {
    ...prop,
    injuryStatus: context.status || '',
    injuryNote: context.note || '',
    injuryUpdated: context.lastUpdated || ''
  };
}

function shouldHideProp(prop) {
  const status = canonicalInjuryStatus(prop?.injuryStatus || prop?.playerStatus || prop?.status);
  return status === 'out' || status === 'doubtful';
}

function applyInjuryContextToList(items, injuryLookup) {
  return (items || [])
    .map(item => decoratePropInjury(item, injuryLookup))
    .filter(item => !shouldHideProp(item));
}

function applyInjuryContextToHomeInsights(homeInsights, injuryLookup) {
  if (!homeInsights || !homeInsights.byDate) return homeInsights || {};
  const next = JSON.parse(JSON.stringify(homeInsights));
  Object.keys(next.byDate).forEach(date => {
    const day = next.byDate[date];
    Object.keys(day || {}).forEach(key => {
      if (Array.isArray(day[key])) {
        day[key] = applyInjuryContextToList(day[key], injuryLookup);
      }
    });
  });
  return next;
}

function injuryBadgeHtml(prop) {
  const status = canonicalInjuryStatus(prop?.injuryStatus || prop?.playerStatus || '');
  if (status !== 'probable' && status !== 'questionable') return '';
  return `<span class="injury-badge injury-${status}">${escapeHtml(titleCaseWord(status))}</span>`;
}

function playerBadgeHtml(name, prop) {
  return `<span class="player-with-badge"><span class="player-name-only">${escapeHtml(name || '')}</span>${injuryBadgeHtml(prop)}</span>`;
}


function fmt(num, digits = 1) {
  const n = Number(num);
  return Number.isFinite(n) ? n.toFixed(digits) : 'N/A';
}

function fmtSigned(num, digits = 1) {
  const n = Number(num);
  if (!Number.isFinite(n)) return 'N/A';
  return `${n >= 0 ? '+' : ''}${n.toFixed(digits)}`;
}

function fmtPct(num, digits = 1) {
  const n = Number(num);
  return Number.isFinite(n) ? `${(n * 100).toFixed(digits)}%` : 'N/A';
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function uniqueLeagues(games) {
  return [...new Set((games || []).map(g => g.league).filter(Boolean))].sort();
}

function modelAwaySpread(game) {
  const away = Number(game?.modelAwayScore);
  const home = Number(game?.modelHomeScore);
  if (Number.isFinite(away) && Number.isFinite(home)) {
    // Away-team spread perspective for "AWAY @ HOME"
    // positive = away underdog, negative = away favorite
    return home - away;
  }

  const fallback = Number(game?.modelHomeSpread);
  return Number.isFinite(fallback) ? -fallback : NaN;
}

function marketAwaySpread(game) {
  const spread = Number(game?.marketSpread);
  return Number.isFinite(spread) ? spread : NaN;
}

function marketSpreadText(game) {
  const spread = marketAwaySpread(game);
  return spreadTeamLabel(game, spread);
}

function marketTotalText(game) {
  return hasNumericValue(game.marketTotal) ? fmt(game.marketTotal) : 'N/A';
}

function gameCard(game) {
  const modelSpread = modelSpreadForDisplay(game);
  const marketSpread = marketSpreadForDisplay(game);
  const edgeSpread = spreadEdgeForDisplay(game);
  const edgeTotal = hasNumericValue(game.marketTotal) ? Number(game.modelTotal) - Number(game.marketTotal) : NaN;

  return `
      <article class="game-card">
        <div class="meta-row">
          <span class="tag">${escapeHtml(game.league || '')}</span>
          <span>${escapeHtml(game.gameDate || '')}</span>
        </div>
        <div>
          <h3>${escapeHtml(game.awayTeam)} @ ${escapeHtml(game.homeTeam)}</h3>
          ${gameMarketSignalsHtml(game)}
        </div>
        <div class="score-box">
          <div class="score-row"><span>${escapeHtml(game.awayTeam)}</span><strong>${fmt(game.modelAwayScore)}</strong></div>
          <div class="score-row"><span>${escapeHtml(game.homeTeam)}</span><strong>${fmt(game.modelHomeScore)}</strong></div>
        </div>
        <div class="kpi-row">
          <div class="kpi"><span>Model spread</span><strong>${modelSpreadText(game)}</strong></div>
          <div class="kpi"><span>Market spread</span><strong>${marketSpreadText(game)}</strong></div>
          <div class="kpi"><span>Spread edge</span><strong>${spreadEdgeText(game)}</strong></div>
        </div>
        <div class="kpi-row">
          <div class="kpi"><span>Model total</span><strong>${fmt(game.modelTotal)}</strong></div>
          <div class="kpi"><span>Market total</span><strong>${marketTotalText(game)}</strong></div>
          <div class="kpi"><span>Total edge</span><strong>${Number.isFinite(edgeTotal) ? fmtSigned(edgeTotal) : 'N/A'}</strong></div>
        </div>
        <div class="meta-row">
          <span>Confidence: ${escapeHtml(game.confidence || 'N/A')}</span>
          <a href="game.html?id=${encodeURIComponent(game.id)}">Open detail</a>
        </div>
      </article>
    `;
}

function renderGameSection(games, rootId, league = 'ALL') {
  const root = byId(rootId);
  if (!root) return;
  const filtered = league === 'ALL' ? games : games.filter(g => g.league === league);
  if (!filtered.length) {
    root.innerHTML = '<div class="empty-state">No games found for this league.</div>';
    return;
  }
  root.innerHTML = filtered.map(gameCard).join('');
}

function normalizeAnalyzerStat(value) {
  const raw = String(value || '').trim().toUpperCase();
  const map = {
    STRIKEOUTS: 'K',
    STRIKEOUT: 'K',
    WALKS: 'BB',
    HITS: 'H',
    'TOTAL BASES': 'TB',
    TOTALBASES: 'TB',
    'HOME RUNS': 'HR',
    HOMERUNS: 'HR',
    DOUBLES: '2B',
    STEALS: 'SB',
    STOLENBASES: 'SB',
    STOLEN_BASES: 'SB',
    RBI: 'RBI',
    RUNS: 'R',
    'HR+R+RBI': 'HRR',
    HRR: 'HRR',
    IP: 'IP',
    OUTS: 'OUTS',
    'HITS ALLOWED': 'HA',
    'EARNED RUNS': 'ER',
    EARNEDRUNS: 'ER'
  };
  return map[raw] || raw;
}

function propAnalyzerHref(prop, fallbackStat = '') {
  const params = new URLSearchParams();
  const league = String(prop?.league || 'NBA').toUpperCase();
  if (league) params.set('league', league);
  if (propDateValue(prop)) params.set('date', propDateValue(prop));
  if (prop?.playerId || prop?.PLAYER_ID) params.set('playerId', String(prop.playerId || prop.PLAYER_ID));
  else if (prop?.player || prop?.PLAYER_NAME) params.set('player', String(prop.player || prop.PLAYER_NAME));
  const stat = normalizeAnalyzerStat(prop?.stat || prop?.stat_display || fallbackStat);
  if (stat) params.set('stat', stat);
  if (prop?.line !== undefined && prop?.line !== null && prop?.line !== '') params.set('line', String(prop.line));
  return `props_analyzer.html?${params.toString()}`;
}


function probabilitySourceText(p) {
  return String(p.probabilityText ?? p.probability_note ?? p.matchup ?? p.note ?? '');
}

function coerceProbability(value) {
  if (value === null || value === undefined || value === '') return NaN;

  if (typeof value === 'string') {
    const cleaned = value.replace('%', '').trim();
    const n = Number(cleaned);
    if (Number.isFinite(n)) return n > 1 ? n / 100 : n;
    return NaN;
  }

  const n = Number(value);
  if (!Number.isFinite(n)) return NaN;
  return n > 1 ? n / 100 : n;
}

function propProbabilityValue(p) {
  const candidates = [
    p?.prob_cons,
    p?.probability,
    p?.clearProbability,
    p?.clear_probability,
    p?.prob,
    p?.winProbability,
    p?.win_probability
  ];

  let sawZero = false;

  for (const value of candidates) {
    const n = coerceProbability(value);
    if (!Number.isFinite(n)) continue;
    if (n > 0) return n;
    if (n === 0) sawZero = true;
  }

  const src = probabilitySourceText(p);
  const match = src.match(/(\d+(?:\.\d+)?)%\s*(?:to\s+clear|clear|over|under|hit)?/i);
  if (match) {
    const n = Number(match[1]);
    if (Number.isFinite(n)) return n / 100;
  }

  return sawZero ? 0 : NaN;
}

function propProbabilityText(p) {
  const n = propProbabilityValue(p);
  return Number.isFinite(n) ? `${(n * 100).toFixed(1)}%` : 'N/A';
}

function propMatchupText(p) {
  if (p?.matchup && String(p.matchup).trim()) return String(p.matchup).trim();

  const team = String(p?.team || '').trim();
  const opp = String(p?.opp || '').trim();
  if (team && opp) return `${team} vs ${opp}`;

  const src = probabilitySourceText(p);
  if (!src) return 'N/A';

  const cleaned = src
    .replace(/\s*[•\-|–—]\s*\d+(?:\.\d+)?%.*$/i, '')
    .replace(/\s+\d+(?:\.\d+)?%.*$/i, '')
    .trim();

  return cleaned || 'N/A';
}

function flattenPropsSource(data) {
  if (Array.isArray(data)) return data;
  if (Array.isArray(data?.items)) return data.items;
  if (Array.isArray(data?.props)) return data.props;
  if (Array.isArray(data?.rows)) return data.rows;

  if (data?.byDate && typeof data.byDate === 'object') {
    return Object.entries(data.byDate).flatMap(([date, day]) =>
      (day?.allProps || []).map(prop => ({
        ...prop,
        gameDate: prop?.gameDate || prop?.date || prop?.GAME_DATE || date
      }))
    );
  }

  return [];
}

function normalizeGameNumericId(value) {
  const raw = String(value ?? '');
  const match = raw.match(/(\d{7,})/);
  return match ? match[1] : '';
}

function buildGameLookup(games) {
  const byGameId = new Map();
  const byGameIdDate = new Map();

  (games || []).forEach(game => {
    const gid = normalizeGameNumericId(game?.sourceGameId || game?.id || game?.gameId || '');
    if (!gid) return;

    const date = String(game?.gameDate || '').trim();
    byGameId.set(gid, game);
    if (date) byGameIdDate.set(`${gid}|${date}`, game);
  });

  return { byGameId, byGameIdDate };
}

function resolveGameForProp(prop, gameLookup) {
  const gid = normalizeGameNumericId(prop?.gameId || prop?.game_id || prop?.GAME_ID || '');
  const date = String(propDateValue(prop) || '').trim();
  if (!gid) return null;
  return gameLookup.byGameIdDate.get(`${gid}|${date}`) || gameLookup.byGameId.get(gid) || null;
}

function propModelValue(p) {
  const candidates = [p?.modelPrediction, p?.model, p?.pred_anchor, p?.mu_cons];
  for (const value of candidates) {
    const n = Number(value);
    if (Number.isFinite(n)) return n;
  }
  return NaN;
}

function propAverageValue(p) {
  const candidates = [p?.avg_anchor, p?.average, p?.avg];
  for (const value of candidates) {
    const n = Number(value);
    if (Number.isFinite(n)) return n;
  }
  return NaN;
}

function propLineValue(p) {
  const n = Number(p?.line);
  return Number.isFinite(n) ? n : NaN;
}

function propLineRatio(p) {
  const direct = [p?.line_to_avg, p?.lineToAvg, p?.line_to_pred, p?.lineToPred];
  for (const value of direct) {
    const n = Number(value);
    if (Number.isFinite(n) && n > 0) return n;
  }

  const line = propLineValue(p);
  const avg = propAverageValue(p);
  if (Number.isFinite(line) && Number.isFinite(avg) && avg > 0) return line / avg;

  const model = propModelValue(p);
  if (Number.isFinite(line) && Number.isFinite(model) && model > 0) return line / model;

  return NaN;
}

function propClosenessScore(p) {
  const ratio = propLineRatio(p);
  if (!Number.isFinite(ratio)) return 0.45;
  const clamped = Math.max(0, Math.min(ratio, 1.25));
  return Math.max(0, 1 - Math.abs(1 - clamped));
}

function propDisplayScore(p) {
  const prob = Number.isFinite(propProbabilityValue(p)) ? propProbabilityValue(p) : 0;
  const closeness = propClosenessScore(p);
  const stability = Number.isFinite(Number(p?.stability_score)) ? Number(p.stability_score) : 0;
  const minutes = Number.isFinite(Number(p?.minutes_score)) ? Number(p.minutes_score) : 0;
  const agreement = Number.isFinite(Number(p?.agreement_score)) ? Number(p.agreement_score) : 0;

  return prob * 0.50 + closeness * 0.20 + stability * 0.15 + minutes * 0.10 + agreement * 0.05;
}

function isReasonableHomepageProp(p, { probFloor = 0.56, ratioFloor = 0.68 } = {}) {
  const prob = propProbabilityValue(p);
  if (Number.isFinite(prob) && prob < probFloor) return false;

  const ratio = propLineRatio(p);
  if (Number.isFinite(ratio) && ratio < ratioFloor) return false;

  return true;
}

function propConfidenceLabel(p) {
  const prob = propProbabilityValue(p);
  const score = propDisplayScore(p);

  if ((Number.isFinite(prob) && prob >= 0.70) || score >= 0.78) return 'High';
  if ((Number.isFinite(prob) && prob >= 0.60) || score >= 0.66) return 'Medium';
  return 'Lean';
}

function enrichHomepageProp(prop, gameLookup) {
  const game = resolveGameForProp(prop, gameLookup);
  const location = String(prop?.location || '').trim().toLowerCase();

  let team = String(prop?.team || '').trim();
  let opp = String(prop?.opp || '').trim();

  if (game) {
    const away = String(game?.awayTeam || '').trim();
    const home = String(game?.homeTeam || '').trim();

    if (!team) {
      if (location === 'away') team = away;
      else if (location === 'home') team = home;
    }

    if (!opp) {
      if (location === 'away') opp = home;
      else if (location === 'home') opp = away;
    }
  }

  const matchup =
    String(prop?.matchup || '').trim() ||
    (team && opp ? `${team} vs ${opp}` : (game ? `${game.awayTeam} vs ${game.homeTeam}` : ''));

  const model = propModelValue(prop);

  return {
    ...prop,
    gameDate: propDateValue(prop),
    league: prop?.league || game?.league || 'NBA',
    team,
    opp,
    matchup,
    modelPrediction: Number.isFinite(model) ? model : '',
    confidence: prop?.confidence || propConfidenceLabel(prop)
  };
}

function pickBestHomepageVariant(rows) {
  return rows
    .slice()
    .sort((a, b) => {
      const scoreDiff = propDisplayScore(b) - propDisplayScore(a);
      if (scoreDiff) return scoreDiff;

      const probDiff = propProbabilityValue(b) - propProbabilityValue(a);
      if (Number.isFinite(probDiff) && probDiff) return probDiff;

      const modelDiff = propModelValue(b) - propModelValue(a);
      if (Number.isFinite(modelDiff) && modelDiff) return modelDiff;

      return 0;
    })[0] || null;
}

function selectHomepageTopProps(props, limit = 12) {
  const groups = new Map();

  (props || []).forEach(prop => {
    const key = [
      normalizeLookupToken(prop?.player || ''),
      String(prop?.stat || prop?.stat_display || '').toUpperCase(),
      String(prop?.gameDate || ''),
      normalizeGameNumericId(prop?.gameId || prop?.game_id || prop?.GAME_ID || '')
    ].join('|');

    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(prop);
  });

  const deduped = Array.from(groups.values())
    .map(group => pickBestHomepageVariant(group))
    .filter(Boolean);

  const preferred = deduped.filter(p => isReasonableHomepageProp(p, { probFloor: 0.58, ratioFloor: 0.70 }));
  const usable = preferred.length >= Math.min(limit, 6)
    ? preferred
    : deduped.filter(p => isReasonableHomepageProp(p, { probFloor: 0.54, ratioFloor: 0.64 }));

  return (usable.length ? usable : deduped)
    .slice()
    .sort((a, b) => {
      const scoreDiff = propDisplayScore(b) - propDisplayScore(a);
      if (scoreDiff) return scoreDiff;

      const probDiff = propProbabilityValue(b) - propProbabilityValue(a);
      if (Number.isFinite(probDiff) && probDiff) return probDiff;

      return propModelValue(b) - propModelValue(a);
    })
    .slice(0, limit);
}

function renderProps(props, bodyId = 'props-body') {
  const body = byId(bodyId);
  if (!body) return;

  const visibleProps = props || [];
  if (!visibleProps.length) {
    body.innerHTML = '<tr><td colspan="8">No props available.</td></tr>';
    return;
  }

  body.innerHTML = visibleProps.map(p => {
    const canLink = ['NBA', 'MLB'].includes(String(p.league || '').toUpperCase());
    const playerHtml = canLink
      ? `<a class="table-link" href="${propAnalyzerHref(p)}">${playerBadgeHtml(p.player || '', p)}</a>`
      : playerBadgeHtml(p.player || '', p);
    return `
    <tr>
      <td>${escapeHtml(p.league || 'NBA')}</td>
      <td>${playerHtml}</td>
      <td>${escapeHtml(p.stat_display || p.stat || '')}</td>
      <td>${escapeHtml(hasNumericValue(p.line) ? fmt(p.line, 1) : (p.line ?? ''))}</td>
      <td>${escapeHtml(hasNumericValue(p.modelPrediction) ? fmt(p.modelPrediction, 1) : (p.modelPrediction ?? ''))}</td>
      <td>${escapeHtml(propProbabilityText(p))}</td>
      <td>${escapeHtml(p.confidence || propConfidenceLabel(p))}</td>
      <td>${escapeHtml(propMatchupText(p))}</td>
    </tr>
  `;}).join('');
}

function resultOutcome(result) {
  const normalized = String(result || '').trim().toLowerCase();
  if (!normalized) return '';
  if (/\bwin\b/.test(normalized)) return 'win';
  if (/\bloss\b/.test(normalized)) return 'loss';
  if (/\bpush\b/.test(normalized)) return 'push';
  if (normalized === 'n/a') return 'na';
  return '';
}

function resultBadgeClass(result) {
  const outcome = resultOutcome(result);
  if (outcome === 'win') return 'badge-win';
  if (outcome === 'loss') return 'badge-loss';
  if (outcome === 'push') return 'badge-push';
  return 'badge-na';
}

function parseResultScoreValues(text) {
  const matches = String(text || '').match(/-?\d+(?:\.\d+)?/g) || [];
  if (matches.length < 2) return [];
  return matches.slice(-2).map(Number).filter(Number.isFinite);
}

function parseMatchupTeams(text) {
  const raw = String(text || '').trim();
  if (!raw) return { away: '', home: '' };
  if (raw.includes('@')) {
    const [away, home] = raw.split('@').map(part => String(part || '').trim());
    return { away, home };
  }
  if (/\bvs\b/i.test(raw)) {
    const [home, away] = raw.split(/\bvs\b/i).map(part => String(part || '').trim());
    return { away, home };
  }
  return { away: '', home: '' };
}

function inferredSpreadLabel(row) {
  const marketSpread = Number(row?.marketSpread);
  if (!Number.isFinite(marketSpread)) return '';

  const league = String(row?.league || '').toUpperCase().trim();
  const predictedVals = parseResultScoreValues(row?.predicted || '');
  const actualVals = parseResultScoreValues(row?.actual || '');
  const teams = parseMatchupTeams(row?.matchup || '');

  const predMargin = predictedVals.length === 2 ? predictedVals[1] - predictedVals[0] : NaN; // home - away
  const actualMargin = actualVals.length === 2 ? actualVals[1] - actualVals[0] : NaN;       // home - away
  if (!Number.isFinite(predMargin)) return '';

  let pickTeam = '';
  let pickLine = marketSpread;
  let resolvedOutcome = '';

  if (league === 'CBB' || league === 'NHL') {
    // CBB and NHL results rows are carrying the spread from the AWAY-team perspective.
    // Example: away +1.5  <=> home -1.5
    const predEdge = marketSpread - predMargin;
    if (Math.abs(predEdge) < 1e-9) return 'Push';

    const pickAway = predEdge > 0;
    pickTeam = pickAway ? (teams.away || 'Away') : (teams.home || 'Home');
    pickLine = pickAway ? marketSpread : -marketSpread;

    if (Number.isFinite(actualMargin)) {
      const actualEdge = marketSpread - actualMargin;
      if (Math.abs(actualEdge) < 1e-9) {
        resolvedOutcome = 'Push';
      } else {
        const actualAwayCover = actualEdge > 0;
        resolvedOutcome = actualAwayCover === pickAway ? 'Win' : 'Loss';
      }
    }
  } else {
    // NBA/NHL results rows are carrying the spread from the HOME-team perspective.
    // Example: home -2.5  <=> away +2.5
    const predEdge = predMargin + marketSpread;
    if (Math.abs(predEdge) < 1e-9) return 'Push';

    const pickHome = predEdge > 0;
    pickTeam = pickHome ? (teams.home || 'Home') : (teams.away || 'Away');
    pickLine = pickHome ? marketSpread : -marketSpread;

    if (Number.isFinite(actualMargin)) {
      const actualEdge = actualMargin + marketSpread;
      if (Math.abs(actualEdge) < 1e-9) {
        resolvedOutcome = 'Push';
      } else {
        const actualHomeCover = actualEdge > 0;
        resolvedOutcome = actualHomeCover === pickHome ? 'Win' : 'Loss';
      }
    }
  }

  return `${pickTeam ? `${pickTeam} ` : ''}${fmtSigned(pickLine)}${resolvedOutcome ? ` ${resolvedOutcome}` : ''}`.trim();
}

function inferredTotalLabel(row) {
  const marketTotal = Number(row?.marketTotal);
  if (!Number.isFinite(marketTotal)) return '';

  const existingOutcome = resultOutcome(row?.totalResult || '');
  const predictedVals = parseResultScoreValues(row?.predicted || '');
  const actualVals = parseResultScoreValues(row?.actual || '');
  const predTotal = predictedVals.length === 2 ? predictedVals[0] + predictedVals[1] : NaN;
  const actualTotal = actualVals.length === 2 ? actualVals[0] + actualVals[1] : NaN;

  const side = Number.isFinite(predTotal)
    ? (predTotal > marketTotal ? 'O' : predTotal < marketTotal ? 'U' : '')
    : '';

  let outcome = existingOutcome;
  if (!outcome && Number.isFinite(actualTotal) && side) {
    outcome = actualTotal === marketTotal ? 'push' : (side === 'O' ? actualTotal > marketTotal : actualTotal < marketTotal) ? 'win' : 'loss';
  } else if (!outcome && Number.isFinite(actualTotal) && actualTotal === marketTotal) {
    outcome = 'push';
  }

  return `${side ? `${side} ` : ''}${fmt(marketTotal)}${outcome ? ` ${outcome[0].toUpperCase()}${outcome.slice(1)}` : ''}`.trim();
}

function formatSpreadResultCell(row) {
  const existing = String(row?.spreadResult || '').trim();
  const label = existing && existing.toLowerCase() !== 'n/a'
    ? existing
    : (inferredSpreadLabel(row) || 'N/A');
  return `<span class="result-badge ${resultBadgeClass(label)}">${escapeHtml(label)}</span>`;
}

function formatTotalResultCell(row) {
  const existing = String(row?.totalResult || '').trim();
  const label = /\d/.test(existing) ? existing : inferredTotalLabel(row) || existing || 'N/A';
  return `<span class="result-badge ${resultBadgeClass(label)}">${escapeHtml(label)}</span>`;
}


function normalizeResultOutcome(value) {
  const s = String(value || '').trim().toLowerCase();
  if (!s) return 'N/A';
  if (s === 'win' || s.endsWith(' win') || s.includes(' win')) return 'Win';
  if (s === 'loss' || s.endsWith(' loss') || s.includes(' loss')) return 'Loss';
  if (s === 'push' || s.endsWith(' push') || s.includes(' push')) return 'Push';
  return 'N/A';
}

function resultBucket(rows, field) {
  let wins = 0, losses = 0, pushes = 0;
  (rows || []).forEach(row => {
    const label = normalizeResultOutcome(row?.[field]);
    if (label === 'Win') wins += 1;
    else if (label === 'Loss') losses += 1;
    else if (label === 'Push') pushes += 1;
  });
  const graded = wins + losses + pushes;
  return {
    wins, losses, pushes, graded,
    winPct: wins + losses ? Number(((wins / (wins + losses)) * 100).toFixed(1)) : null,
  };
}

function summarizeRows(rows) {
  return {
    ML: resultBucket(rows, 'mlResult'),
    Spread: resultBucket(rows, 'spreadResult'),
    Total: resultBucket(rows, 'totalResult'),
  };
}

function recomputeResultsSummaryFromHistory(historyRows, templateSummary = {}) {
  const periods = templateSummary?.periods || {};
  const out = { ...(templateSummary || {}), periods: {} };
  Object.keys(periods).forEach(key => {
    const period = periods[key] || {};
    const start = String(period.startDate || '');
    const end = String(period.endDate || '');
    const subset = (historyRows || []).filter(row => {
      const d = String(row?.date || '');
      return d && (!start || d >= start) && (!end || d <= end);
    });
    const byLeague = {};
    Array.from(new Set(subset.map(r => String(r?.league || '')).filter(Boolean))).sort().forEach(league => {
      byLeague[league] = summarizeRows(subset.filter(r => String(r?.league || '') === league));
    });
    out.periods[key] = {
      ...period,
      overall: summarizeRows(subset),
      byLeague,
      rowCount: subset.length,
    };
  });
  return out;
}

function filterResultsForLaunch(rows, launchDate) {
  const launch = String(launchDate || '').trim();
  return (rows || []).filter(row => {
    if (String(row?.league || '').toUpperCase() !== 'MLB') return true;
    return launch && String(row?.date || '') >= launch;
  });
}

function sortResultsRows(rows) {
  return (rows || []).slice().sort((a, b) => {
    const aKey = `${String(a?.date || '')}|${String(a?.league || '')}|${String(a?.matchup || '')}`;
    const bKey = `${String(b?.date || '')}|${String(b?.league || '')}|${String(b?.matchup || '')}`;
    return bKey.localeCompare(aKey);
  });
}

function selectDisplayResultsRows(resultsRows, historyRows, preferredDate = '') {
  const rowsForDate = (rows, date) => (rows || []).filter(row => String(row?.date || '') === String(date || ''));
  const withPreferredDate = String(preferredDate || '').trim();

  if (withPreferredDate) {
    const historySlice = rowsForDate(historyRows, withPreferredDate);
    if (historySlice.length) return sortResultsRows(historySlice);

    const resultsSlice = rowsForDate(resultsRows, withPreferredDate);
    if (resultsSlice.length) return sortResultsRows(resultsSlice);
  }

  const historyDates = Array.from(new Set((historyRows || []).map(row => String(row?.date || '')).filter(Boolean))).sort();
  const latestHistoryDate = historyDates.length ? historyDates[historyDates.length - 1] : '';
  if (latestHistoryDate) {
    const historySlice = rowsForDate(historyRows, latestHistoryDate);
    if (historySlice.length) return sortResultsRows(historySlice);
  }

  return sortResultsRows(resultsRows || []);
}

function renderResults(results) {
  const body = byId('results-body');
  if (!body) return;
  const items = Array.isArray(results) ? results : [];
  if (!items.length) {
    body.innerHTML = '<tr><td colspan="8">No game results match this view yet.</td></tr>';
    return;
  }
  body.innerHTML = items.map(r => `
    <tr>
      <td>${escapeHtml(r.date || '')}</td>
      <td>${escapeHtml(r.league || '')}</td>
      <td>${escapeHtml(r.matchup || '')}</td>
      <td>${escapeHtml(r.predicted || '')}</td>
      <td>${escapeHtml(r.actual || '')}</td>
      <td><span class="result-badge ${resultBadgeClass(r.mlResult)}">${escapeHtml(r.mlResult || '')}</span></td>
      <td><span class="result-badge ${resultBadgeClass(r.spreadResult)}">${escapeHtml(r.spreadResult || '')}</span></td>
      <td><span class="result-badge ${resultBadgeClass(r.totalResult)}">${escapeHtml(r.totalResult || '')}</span></td>
    </tr>
  `).join('');
}

function resultRowSearchText(row) {
  return normalizeSearchText([
    row?.date,
    row?.league,
    row?.matchup,
    row?.predicted,
    row?.actual,
    row?.mlResult,
    row?.spreadResult,
    row?.totalResult,
  ].join(' '));
}

function renderResultsViewSummary(rows, context = {}) {
  const root = byId('results-view-summary-grid');
  if (!root) return;
  const dateLabel = context?.dateLabel || 'All dates';
  const query = String(context?.query || '').trim();
  if (!rows.length) {
    root.innerHTML = `<div class="empty-state">No game results match ${escapeHtml(dateLabel)}${query ? ` with search "${escapeHtml(query)}"` : ''}.</div>`;
    return;
  }

  const byLeague = {};
  Array.from(new Set(rows.map(r => String(r?.league || '')).filter(Boolean))).sort().forEach(league => {
    byLeague[league] = summarizeRows(rows.filter(r => String(r?.league || '') === league));
  });
  const leagueOrder = ['NBA', 'MLB', 'NHL', 'CBB'];
  const leagues = [...leagueOrder.filter(league => byLeague[league]), ...Object.keys(byLeague).filter(league => !leagueOrder.includes(league)).sort()];
  const searchLine = query ? `Search: ${escapeHtml(query)}` : 'Search: none';

  root.innerHTML = `
    <article class="summary-card">
      <div class="summary-card-head">
        <div>
          <span class="summary-kicker">Current game-results view</span>
          <h3>${escapeHtml(dateLabel)}</h3>
        </div>
        <span class="summary-rows">${escapeHtml(String(rows.length))} games</span>
      </div>
      <p class="muted summary-inline-note">${searchLine}</p>
      <div class="sport-breakdown-grid">
        ${sportSummaryBlockHtml('Overall', summarizeRows(rows), true)}
        ${leagues.map(league => sportSummaryBlockHtml(league, byLeague[league])).join('')}
      </div>
    </article>
  `;
}

function setupResultsExplorer(resultsRows, historyRows, preferredDate = '') {
  const dateSelect = byId('results-date-filter');
  const searchInput = byId('results-search-input');
  const metaNode = byId('results-view-meta');
  const sourceRows = dedupeRowsByKey([...(historyRows || []), ...(resultsRows || [])], row => `${row?.date || ''}|${row?.league || ''}|${row?.matchup || ''}`);
  const sortedRows = sortResultsRows(sourceRows);
  const dates = uniqueSortedDates(sortedRows);
  populateDateSelect(dateSelect, dates, preferredDate, 'All graded dates');

  const rerender = () => {
    const selectedDate = dateSelect?.value || dates[0] || '__ALL__';
    const query = normalizeSearchText(searchInput?.value || '');
    const dateLabel = currentDateLabel(selectedDate, 'All graded dates');
    const visibleRows = sortResultsRows(
      filterRowsByDate(sortedRows, selectedDate).filter(row => !query || resultRowSearchText(row).includes(query))
    );

    setText('results-date-label', dateLabel);
    if (metaNode) {
      metaNode.textContent = `${visibleRows.length} game${visibleRows.length === 1 ? '' : 's'} shown`;
    }
    renderResultsViewSummary(visibleRows, { dateLabel, query: searchInput?.value || '' });
    renderResults(visibleRows);
  };

  if (dateSelect && !dateSelect.dataset.bound) {
    dateSelect.addEventListener('change', rerender);
    dateSelect.dataset.bound = '1';
  }
  if (searchInput && !searchInput.dataset.bound) {
    searchInput.addEventListener('input', rerender);
    searchInput.dataset.bound = '1';
  }
  rerender();
}

function summaryMetricParts(metric) {
  const wins = Number(metric?.wins || 0);
  const losses = Number(metric?.losses || 0);
  const pushes = Number(metric?.pushes || 0);
  const graded = Number(metric?.graded || 0);
  const winPct = metric?.winPct;
  return {
    record: pushes > 0 ? `${wins}-${losses}-${pushes}` : `${wins}-${losses}`,
    pctText: graded > 0 && winPct !== null && winPct !== undefined ? `${Number(winPct).toFixed(1)}%` : 'N/A'
  };
}

function sportSummaryBlockHtml(label, metrics, emphasized = false) {
  const classes = emphasized ? 'sport-summary sport-summary-overall' : 'sport-summary';
  return `
    <section class="${classes}">
      <div class="sport-summary-head"><h4>${escapeHtml(label)}</h4></div>
      <div class="sport-summary-metrics">
        ${['ML', 'Spread', 'Total'].map(metricName => {
          const parts = summaryMetricParts(metrics?.[metricName]);
          return `
            <div class="sport-metric-chip">
              <span>${escapeHtml(metricName)}</span>
              <strong>${escapeHtml(parts.record)}</strong>
              <small>${escapeHtml(parts.pctText)}</small>
            </div>
          `;
        }).join('')}
      </div>
    </section>
  `;
}

function periodTitle(key) {
  return ({ yesterday: 'Previous day', weekToDate: 'Current week', monthToDate: 'Current month', yearToDate: 'Current year' })[key] || key;
}

function renderResultsSummary(summary) {
  const root = byId('results-summary-grid');
  if (!root) return;
  const periods = summary?.periods || {};
  const order = ['yesterday', 'weekToDate', 'monthToDate', 'yearToDate'];
  const leagueOrder = ['NBA', 'NHL', 'CBB'];
  const cards = order.filter(key => periods[key]).map(key => {
    const period = periods[key];
    const byLeague = period.byLeague || {};
    const leagues = [...leagueOrder.filter(league => byLeague[league]), ...Object.keys(byLeague).filter(league => !leagueOrder.includes(league)).sort()];
    return `
      <article class="summary-card">
        <div class="summary-card-head">
          <div>
            <span class="summary-kicker">${escapeHtml(periodTitle(key))}</span>
            <h3>${escapeHtml(period.startDate === period.endDate ? period.endDate : `${period.startDate} to ${period.endDate}`)}</h3>
          </div>
          <span class="summary-rows">${escapeHtml(period.rowCount ?? 0)} games</span>
        </div>
        <div class="sport-breakdown-grid">
          ${sportSummaryBlockHtml('Overall', period.overall, true)}
          ${leagues.map(league => sportSummaryBlockHtml(league, byLeague[league])).join('')}
        </div>
      </article>
    `;
  });
  root.innerHTML = cards.length ? cards.join('') : '<div class="empty-state">No summary results available yet.</div>';
}


function propStatDisplay(stat) {
  const key = String(stat || '').toUpperCase().trim();
  const map = { H: 'Hits', TB: 'Total Bases', '2B': 'Doubles', HR: 'Home Runs', K: 'Strikeouts', BB: 'Walks', SB: 'Steals', RBI: 'RBI', R: 'Runs', HRR: 'HR+R+RBI', OUTS: 'Outs', IP: 'IP', HA: 'Hits Allowed', ER: 'Earned Runs' };
  return map[key] || key || 'Other';
}

function renderMlbPropResultsSummary(summary, pending) {
  const root = byId('mlb-prop-results-summary-grid');
  if (!root) return;
  const overall = summary?.overall || null;
  const latestSettledDate = summary?.latestSettledDate || '';
  const pendingCount = Array.isArray(pending) ? pending.length : 0;
  const byStat = summary?.byStat || {};
  const orderedStats = ['H','TB','HR','HRR','K','BB','RBI','R','SB','OUTS','IP','HA','ER'];
  const stats = [
    ...orderedStats.filter(stat => byStat[stat]),
    ...Object.keys(byStat).filter(stat => !orderedStats.includes(stat)).sort((a, b) => (Number(byStat[b]?.settled || 0) - Number(byStat[a]?.settled || 0)) || String(a).localeCompare(String(b)))
  ].slice(0, 6);

  if (!overall || !Number(overall.settled || 0)) {
    root.innerHTML = `<div class="empty-state">No settled MLB prop results yet.${pendingCount ? ` ${pendingCount} props are still pending.` : ''}</div>`;
    const label = byId('mlb-prop-results-date-label');
    if (label) label.textContent = latestSettledDate || '—';
    const pendingNode = byId('mlb-prop-results-pending-count');
    if (pendingNode) pendingNode.textContent = String(pendingCount || 0);
    return;
  }

  const overallParts = summaryMetricParts({
    wins: overall.wins,
    losses: overall.losses,
    pushes: overall.pushes,
    graded: overall.decisionCount,
    winPct: overall.winRate != null ? Number(overall.winRate) * 100 : null
  });

  const label = byId('mlb-prop-results-date-label');
  if (label) label.textContent = latestSettledDate || '—';
  const pendingNode = byId('mlb-prop-results-pending-count');
  if (pendingNode) pendingNode.textContent = String(pendingCount || 0);

  root.innerHTML = `
    <article class="summary-card">
      <div class="summary-card-head">
        <div>
          <span class="summary-kicker">MLB props</span>
          <h3>${escapeHtml(latestSettledDate || 'Settled history')}</h3>
        </div>
        <span class="summary-rows">${escapeHtml(String(overall.settled || 0))} settled</span>
      </div>
      <div class="sport-breakdown-grid">
        <section class="sport-summary sport-summary-overall">
          <div class="sport-summary-head"><h4>Overall</h4></div>
          <div class="sport-summary-metrics">
            <div class="sport-metric-chip"><span>Record</span><strong>${escapeHtml(overallParts.record)}</strong><small>${escapeHtml(overallParts.pctText)}</small></div>
            <div class="sport-metric-chip"><span>Pending</span><strong>${escapeHtml(String(pendingCount || 0))}</strong><small>Open props</small></div>
            <div class="sport-metric-chip"><span>Settled</span><strong>${escapeHtml(String(overall.settled || 0))}</strong><small>Tracked props</small></div>
          </div>
        </section>
        ${stats.map(stat => {
          const row = byStat[stat] || {};
          const parts = summaryMetricParts({
            wins: row.wins,
            losses: row.losses,
            pushes: row.pushes,
            graded: row.decisionCount,
            winPct: row.winRate != null ? Number(row.winRate) * 100 : null
          });
          return `
            <section class="sport-summary">
              <div class="sport-summary-head"><h4>${escapeHtml(propStatDisplay(stat))}</h4></div>
              <div class="sport-summary-metrics">
                <div class="sport-metric-chip"><span>Record</span><strong>${escapeHtml(parts.record)}</strong><small>${escapeHtml(parts.pctText)}</small></div>
                <div class="sport-metric-chip"><span>Settled</span><strong>${escapeHtml(String(row.settled || 0))}</strong><small>Rows</small></div>
                <div class="sport-metric-chip"><span>Decisions</span><strong>${escapeHtml(String(row.decisionCount || 0))}</strong><small>Win/Loss only</small></div>
              </div>
            </section>
          `;
        }).join('')}
      </div>
    </article>
  `;
}

function renderMlbPropResults(rows) {
  const body = byId('mlb-prop-results-body');
  if (!body) return;
  const items = Array.isArray(rows)
    ? rows.slice().sort((a, b) => `${b.date || ''}|${b.player || ''}|${b.stat || ''}`.localeCompare(`${a.date || ''}|${a.player || ''}|${a.stat || ''}`))
    : [];
  if (!items.length) {
    body.innerHTML = '<tr><td colspan="8">No settled MLB prop results match this view yet.</td></tr>';
    return;
  }
  body.innerHTML = items.map(r => `
    <tr>
      <td>${escapeHtml(r.date || '')}</td>
      <td>${escapeHtml(r.player || '')}</td>
      <td>${escapeHtml(r.matchup || '')}</td>
      <td>${escapeHtml(propStatDisplay(r.stat))}</td>
      <td>${escapeHtml(fmt(r.line, 1))}</td>
      <td>${escapeHtml(fmt(r.model, 2))}</td>
      <td>${escapeHtml(fmt(r.actual, 1))}</td>
      <td><span class="result-badge ${resultBadgeClass(r.result)}">${escapeHtml(r.result || 'Pending')}</span></td>
    </tr>
  `).join('');
}

function summarizePropResultRows(rows) {
  let wins = 0, losses = 0, pushes = 0;
  (rows || []).forEach(row => {
    const label = normalizeResultOutcome(row?.result);
    if (label === 'Win') wins += 1;
    else if (label === 'Loss') losses += 1;
    else if (label === 'Push') pushes += 1;
  });
  const settled = (rows || []).length;
  const decisionCount = wins + losses + pushes;
  return {
    wins, losses, pushes, settled, decisionCount,
    winRate: wins + losses ? Number((wins / (wins + losses)).toFixed(4)) : null,
  };
}

function isMlbTrackedHomeBoardResultRow(row) {
  const stat = String(row?.stat || '').toUpperCase().trim();
  const board = String(row?.board || '').toLowerCase();
  const line = Number(row?.line);

  // The homepage "Best two-plus total bases" board is strictly a 1.5 TB board.
  // Results should track that same board, not higher alternate TB lines that may
  // exist in the analyzer payload.
  if (stat === 'TB' || board.includes('two-plus total bases')) {
    return Number.isFinite(line) && Math.abs(line - 1.5) < 1e-9;
  }

  return true;
}

function filterMlbTrackedHomeBoardRows(rows) {
  return Array.isArray(rows) ? rows.filter(isMlbTrackedHomeBoardResultRow) : [];
}

function buildMlbPropSummaryFromRows(rows, fallback = {}) {
  const settledRows = filterMlbTrackedHomeBoardRows(rows).filter(row => {
    const label = normalizeResultOutcome(row?.result);
    return label === 'Win' || label === 'Loss' || label === 'Push';
  });

  const byStat = {};
  Array.from(new Set(settledRows.map(row => String(row?.stat || '').toUpperCase().trim()).filter(Boolean))).forEach(stat => {
    byStat[stat] = summarizePropResultRows(settledRows.filter(row => String(row?.stat || '').toUpperCase().trim() === stat));
  });

  const dates = settledRows.map(row => String(row?.date || '').trim()).filter(Boolean).sort();
  return {
    ...fallback,
    latestSettledDate: dates.length ? dates[dates.length - 1] : (fallback?.latestSettledDate || ''),
    overall: summarizePropResultRows(settledRows),
    byStat,
  };
}

function propResultSearchText(row) {
  return normalizeSearchText([
    row?.date,
    row?.player,
    row?.team,
    row?.opp,
    row?.matchup,
    row?.stat,
    propStatDisplay(row?.stat),
    row?.board,
    row?.note,
    row?.result,
    row?.role,
  ].join(' '));
}

function renderMlbPropResultsViewSummary(rows, context = {}) {
  const root = byId('mlb-prop-results-view-summary-grid');
  if (!root) return;
  const dateLabel = context?.dateLabel || 'All settled dates';
  const query = String(context?.query || '').trim();
  const statLabel = String(context?.statLabel || '').trim();

  if (!rows.length) {
    const parts = [dateLabel];
    if (query) parts.push(`search "${query}"`);
    if (statLabel) parts.push(statLabel);
    root.innerHTML = `<div class="empty-state">No settled MLB props match ${escapeHtml(parts.join(' • '))}.</div>`;
    return;
  }

  const overall = summarizePropResultRows(rows);
  const overallParts = summaryMetricParts({
    wins: overall.wins,
    losses: overall.losses,
    pushes: overall.pushes,
    graded: overall.decisionCount,
    winPct: overall.winRate != null ? Number(overall.winRate) * 100 : null,
  });

  const byStat = {};
  Array.from(new Set(rows.map(r => String(r?.stat || '').toUpperCase()).filter(Boolean))).sort().forEach(stat => {
    byStat[stat] = summarizePropResultRows(rows.filter(r => String(r?.stat || '').toUpperCase() === stat));
  });

  const orderedStats = ['H','TB','HR','HRR','K','BB','RBI','R','SB','OUTS','IP','HA','ER'];
  const stats = [...orderedStats.filter(stat => byStat[stat]), ...Object.keys(byStat).filter(stat => !orderedStats.includes(stat)).sort()].slice(0, 6);

  const notes = [];
  if (query) notes.push(`Search: ${escapeHtml(query)}`);
  if (statLabel) notes.push(`Stat: ${escapeHtml(statLabel)}`);
  if (!notes.length) notes.push('Search: none');

  root.innerHTML = `
    <article class="summary-card">
      <div class="summary-card-head">
        <div>
          <span class="summary-kicker">Current MLB prop-results view</span>
          <h3>${escapeHtml(dateLabel)}</h3>
        </div>
        <span class="summary-rows">${escapeHtml(String(rows.length))} props</span>
      </div>
      <p class="muted summary-inline-note">${notes.join(' • ')}</p>
      <div class="sport-breakdown-grid">
        <section class="sport-summary sport-summary-overall">
          <div class="sport-summary-head"><h4>Overall</h4></div>
          <div class="sport-summary-metrics">
            <div class="sport-metric-chip"><span>Record</span><strong>${escapeHtml(overallParts.record)}</strong><small>${escapeHtml(overallParts.pctText)}</small></div>
            <div class="sport-metric-chip"><span>Settled</span><strong>${escapeHtml(String(overall.settled || 0))}</strong><small>Rows</small></div>
            <div class="sport-metric-chip"><span>Decisions</span><strong>${escapeHtml(String(overall.decisionCount || 0))}</strong><small>Win/Loss only</small></div>
          </div>
        </section>
        ${stats.map(stat => {
          const row = byStat[stat] || {};
          const parts = summaryMetricParts({
            wins: row.wins,
            losses: row.losses,
            pushes: row.pushes,
            graded: row.decisionCount,
            winPct: row.winRate != null ? Number(row.winRate) * 100 : null,
          });
          return `
            <section class="sport-summary">
              <div class="sport-summary-head"><h4>${escapeHtml(propStatDisplay(stat))}</h4></div>
              <div class="sport-summary-metrics">
                <div class="sport-metric-chip"><span>Record</span><strong>${escapeHtml(parts.record)}</strong><small>${escapeHtml(parts.pctText)}</small></div>
                <div class="sport-metric-chip"><span>Settled</span><strong>${escapeHtml(String(row.settled || 0))}</strong><small>Rows</small></div>
                <div class="sport-metric-chip"><span>Decisions</span><strong>${escapeHtml(String(row.decisionCount || 0))}</strong><small>Win/Loss only</small></div>
              </div>
            </section>
          `;
        }).join('')}
      </div>
    </article>
  `;
}

function setupMlbPropResultsExplorer(rows, summary, pending) {
  const dateSelect = byId('mlb-prop-results-date-filter');
  const statSelect = byId('mlb-prop-results-stat-filter');
  const searchInput = byId('mlb-prop-results-search-input');
  const metaNode = byId('mlb-prop-results-view-meta');

  const sortedRows = Array.isArray(rows)
    ? rows.slice().sort((a, b) => `${b.date || ''}|${b.player || ''}|${b.stat || ''}`.localeCompare(`${a.date || ''}|${a.player || ''}|${a.stat || ''}`))
    : [];

  const dates = uniqueSortedDates(sortedRows);
  const preferredDate = summary?.latestSettledDate || dates[0] || '';
  populateDateSelect(dateSelect, dates, preferredDate, 'All settled dates');

  if (statSelect) {
    const stats = Array.from(new Set(sortedRows.map(row => String(row?.stat || '').toUpperCase()).filter(Boolean)))
      .sort((a, b) => propStatDisplay(a).localeCompare(propStatDisplay(b)));
    statSelect.innerHTML = [
      '<option value="">All stats</option>',
      ...stats.map(stat => `<option value="${escapeHtml(stat)}">${escapeHtml(propStatDisplay(stat))}</option>`)
    ].join('');
  }

  const rerender = () => {
    const selectedDate = dateSelect?.value || preferredDate || '__ALL__';
    const selectedStat = String(statSelect?.value || '').toUpperCase().trim();
    const query = normalizeSearchText(searchInput?.value || '');
    const dateLabel = currentDateLabel(selectedDate, 'All settled dates');

    const visibleRows = filterRowsByDate(sortedRows, selectedDate).filter(row => {
      if (selectedStat && String(row?.stat || '').toUpperCase() !== selectedStat) return false;
      if (query && !propResultSearchText(row).includes(query)) return false;
      return true;
    });

    const statLabel = selectedStat ? propStatDisplay(selectedStat) : '';
    setText('mlb-prop-results-date-label', dateLabel);

    const pendingNode = byId('mlb-prop-results-pending-count');
    if (pendingNode) pendingNode.textContent = String(Array.isArray(pending) ? pending.length : 0);

    if (metaNode) metaNode.textContent = `${visibleRows.length} prop${visibleRows.length === 1 ? '' : 's'} shown`;

    renderMlbPropResultsViewSummary(visibleRows, {
      dateLabel,
      query: searchInput?.value || '',
      statLabel
    });
    renderMlbPropResults(visibleRows);
  };

  if (dateSelect && !dateSelect.dataset.bound) {
    dateSelect.addEventListener('change', rerender);
    dateSelect.dataset.bound = '1';
  }
  if (statSelect && !statSelect.dataset.bound) {
    statSelect.addEventListener('change', rerender);
    statSelect.dataset.bound = '1';
  }
  if (searchInput && !searchInput.dataset.bound) {
    searchInput.addEventListener('input', rerender);
    searchInput.dataset.bound = '1';
  }

  rerender();
}

function propInsightCard(prop) {
  return `
    <article class="insight-card">
      <div class="insight-topline">
        <span class="tag">${escapeHtml(prop.stat || '')}</span>
        <span class="muted">${escapeHtml(prop.location || '')}</span>
      </div>
      <h4>${playerBadgeHtml(prop.player || '', prop)}</h4>
      <p class="muted">${escapeHtml(prop.team || '')} vs ${escapeHtml(prop.opp || '')}</p>
      <div class="mini-chip-row">
        <span class="mini-chip">Line ${escapeHtml(fmt(prop.line, 1))}</span>
        <span class="mini-chip">Model ${escapeHtml(fmt(prop.pred_anchor ?? prop.mu_cons, 1))}</span>
        <span class="mini-chip">Prob ${escapeHtml(fmtPct(prop.prob_cons))}</span>
      </div>
      <p class="insight-copy">${escapeHtml(prop.boardDriver || prop.summary || '')}</p>
    </article>
  `;
}

function roleCard(prop) {
  const gap = Number(prop.trend_gap);
  return `
    <article class="insight-card compact-card">
      <div class="insight-topline">
        <span class="tag">${escapeHtml(prop.stat || '')}</span>
        <span class="muted">${Number.isFinite(gap) ? fmtSigned(gap, 1) : 'N/A'} vs avg</span>
      </div>
      <h4>${playerBadgeHtml(prop.player || '', prop)}</h4>
      <p class="muted">${escapeHtml(prop.team || '')} vs ${escapeHtml(prop.opp || '')}</p>
      <div class="mini-chip-row">
        <span class="mini-chip">Line ${escapeHtml(fmt(prop.line, 1))}</span>
        <span class="mini-chip">Model ${escapeHtml(fmt(prop.pred_anchor, 1))}</span>
        <span class="mini-chip">Avg ${escapeHtml(fmt(prop.avg_anchor, 1))}</span>
      </div>
    </article>
  `;
}

function renderInsightGrid(rootId, items, role = false) {
  const root = byId(rootId);
  if (!root) return;
  const visibleItems = applyInjuryContextToList(items || [], new Map());
  if (!visibleItems.length) {
    root.innerHTML = '<div class="empty-state">No props available.</div>';
    return;
  }
  root.innerHTML = visibleItems.map(item => role ? roleCard(item) : propInsightCard(item)).join('');
}

function edgeBoardCard(title, items, kind) {
  if (!items.length) {
    return `<article class="insight-board"><h4>${escapeHtml(title)}</h4><div class="empty-state">No lined NBA games yet.</div></article>`;
  }

  const rows = items.map(item => {
    const edge = kind === 'spread' ? item.spreadEdge : item.totalEdge;
    const market = kind === 'spread' ? marketSpreadForDisplay(item) : Number(item.marketTotal);
    const model = kind === 'spread' ? modelSpreadForDisplay(item) : Number(item.modelTotal);

    return `
      <div class="edge-row">
        <div>
          <strong>${escapeHtml(`${item.awayTeam} @ ${item.homeTeam}`)}</strong>
          <span>${
            kind === 'spread'
              ? `Model ${escapeHtml(spreadTeamLabel(item, model))} vs market ${escapeHtml(spreadTeamLabel(item, market))}`
              : `Model ${escapeHtml(fmt(model))} vs market ${escapeHtml(fmt(market))}`
          }</span>
        </div>
        <strong>${escapeHtml(kind === 'spread' ? spreadEdgeText(item) : (Number.isFinite(edge) ? fmtSigned(edge) : 'N/A'))}</strong>
      </div>
    `;
  }).join('');

  return `<article class="insight-board"><h4>${escapeHtml(title)}</h4>${rows}</article>`;
}


function chooseMlbBoardRows(entries, { date, stat, playerType = '', limit = 10, uniqueByPlayer = false, line = null }) {
  const pool = (entries || []).filter(e => String(e?.gameDate || '') === String(date || '') && String(e?.stat || '').toUpperCase() === String(stat).toUpperCase());
  const typed = playerType ? pool.filter(e => String(e?.playerType || '').toLowerCase() === String(playerType).toLowerCase()) : pool;
  let base = typed.length ? typed : pool;
  if (line !== null && line !== undefined) {
    const wantedLine = Number(line);
    base = base.filter(e => {
      const rowLine = Number(e?.line);
      return Number.isFinite(rowLine) && Number.isFinite(wantedLine) && Math.abs(rowLine - wantedLine) < 1e-9;
    });
  }
  if (String(playerType).toLowerCase() === 'pitcher') {
    base = base.filter(e => !/(^|\b)(tbd|to be determined|probable starter tbd)(\b|$)/i.test(String(e?.player || '')));
  }

  const sorted = base.slice().sort((a, b) => {
    if (String(playerType).toLowerCase() === 'pitcher') {
      const predDiff = (Number(b?.pred_anchor ?? b?.mu_cons) || 0) - (Number(a?.pred_anchor ?? a?.mu_cons) || 0);
      if (predDiff) return predDiff;
      const avgDiff = (Number(b?.avg_anchor) || 0) - (Number(a?.avg_anchor) || 0);
      if (avgDiff) return avgDiff;
      return (Number(b?.prob_cons) || -1) - (Number(a?.prob_cons) || -1);
    }
    const probDiff = (Number(b?.prob_cons) || -1) - (Number(a?.prob_cons) || -1);
    if (probDiff) return probDiff;
    return (Number(b?.pred_anchor ?? b?.mu_cons) || 0) - (Number(a?.pred_anchor ?? a?.mu_cons) || 0);
  });

  if (uniqueByPlayer) {
    const grouped = new Map();
    sorted.forEach(item => {
      const key = `${item.playerId || item.player}|${item.stat}`;
      if (grouped.has(key)) return;
      grouped.set(key, item);
    });
    return Array.from(grouped.values()).slice(0, limit);
  }

  const deduped = [];
  const seen = new Set();
  sorted.forEach(item => {
    const key = `${item.playerId || item.player}|${item.stat}|${item.line}`;
    if (seen.has(key)) return;
    seen.add(key);
    deduped.push(item);
  });
  return deduped.slice(0, limit);
}


function mlbBoardDisplayLine(row) {
  const stat = String(row?.stat || '').toUpperCase();
  if (hasNumericValue(row?.line)) return fmt(row.line, 1);
  if (stat === 'H') return '0.5';
  if (stat === 'TB') return '1.5';
  return '—';
}

function mlbBoardTable(title, rows, { showLine = true, showAvg = false, primaryMetric = 'line', primaryLabel = 'Line' } = {}) {
  if (!rows.length) {
    return `<article class="insight-board"><h4>${escapeHtml(title)}</h4><div class="empty-state">No entries available yet.</div></article>`;
  }
  const body = rows.map(row => {
    const primaryValue = primaryMetric === 'average'
      ? (hasNumericValue(row.avg_anchor) ? fmt(row.avg_anchor, 1) : '—')
      : mlbBoardDisplayLine(row);
    return `
    <tr>
      <td><a class="table-link" href="${propAnalyzerHref({ ...row, league: 'MLB', player: row.player, playerId: row.playerId, line: row.line, stat: row.stat })}">${escapeHtml(row.player || '')}</a></td>
      ${showLine ? `<td>${escapeHtml(primaryValue)}</td>` : ''}
      <td>${escapeHtml(hasNumericValue(row.pred_anchor ?? row.mu_cons) ? fmt(row.pred_anchor ?? row.mu_cons, 1) : '—')}</td>
      ${showAvg ? `<td>${escapeHtml(hasNumericValue(row.avg_anchor) ? fmt(row.avg_anchor, 1) : '—')}</td>` : ''}
      <td>${escapeHtml(Number.isFinite(Number(row.prob_cons)) ? `${(Number(row.prob_cons) * 100).toFixed(1)}%` : '—')}</td>
      <td>${escapeHtml(propMatchupText(row))}</td>
    </tr>
  `;
  }).join('');
  return `
    <article class="insight-board">
      <h4>${escapeHtml(title)}</h4>
      <div class="table-wrap compact-table-wrap">
        <table class="compact-table">
          <thead><tr><th>Player</th>${showLine ? `<th>${escapeHtml(primaryLabel)}</th>` : ''}<th>Model</th>${showAvg ? '<th>Avg.</th>' : ''}<th>Prob.</th><th>Matchup</th></tr></thead>
          <tbody>${body}</tbody>
        </table>
      </div>
    </article>
  `;
}

function renderMlbHomeBoards(mlbAnalyzer, meta) {
  const root = byId('mlb-home-props-grid');
  if (!root) return;
  const entries = mlbAnalyzer?.entries || [];
  root.innerHTML = [
    mlbBoardTable('Best hits', chooseMlbBoardRows(entries, { date: meta?.targetDate, stat: 'H', playerType: 'batter', limit: 10 })),
    mlbBoardTable('Best two-plus total bases', chooseMlbBoardRows(entries, { date: meta?.targetDate, stat: 'TB', playerType: 'batter', line: 1.5, limit: 10 })),
    mlbBoardTable('Top pitcher strikeouts', chooseMlbBoardRows(entries, { date: meta?.targetDate, stat: 'K', playerType: 'pitcher', limit: 10, uniqueByPlayer: true }), { showLine: true, showAvg: false, primaryMetric: 'average', primaryLabel: 'Avg.' })
  ].join('');
}

function renderNbaGameEdges(games, meta) {
  const root = byId('nba-game-edges-grid');
  if (!root) return;

  const nba = (games || []).filter(g => g.league === 'NBA' && g.gameDate === meta.targetDate);
  const lined = nba.map(g => ({
    ...g,
    spreadEdge: spreadEdgeForDisplay(g),
    totalEdge: hasNumericValue(g.marketTotal)
      ? Number(g.modelTotal) - Number(g.marketTotal)
      : NaN
  }));

  const spreadTop = lined
    .filter(g => Number.isFinite(g.spreadEdge))
    .sort((a, b) => Math.abs(b.spreadEdge) - Math.abs(a.spreadEdge))
    .slice(0, 4);

  const totalTop = lined
    .filter(g => Number.isFinite(g.totalEdge))
    .sort((a, b) => Math.abs(b.totalEdge) - Math.abs(a.totalEdge))
    .slice(0, 4);

  root.innerHTML = [
    edgeBoardCard('Biggest spread gaps', spreadTop, 'spread'),
    edgeBoardCard('Biggest total gaps', totalTop, 'total')
  ].join('');
}

function renderHomeInsights(homeInsights, meta) {
  const day = homeInsights?.byDate?.[meta.targetDate];
  if (!day) return;
  renderInsightGrid('home-consensus-grid', day.consensusTop);
  renderInsightGrid('home-floor-grid', day.floorTop);
  renderInsightGrid('home-ceiling-grid', day.ceilingTop);
  renderInsightGrid('home-role-up-grid', day.roleUp, true);
  renderInsightGrid('home-role-down-grid', day.roleDown, true);
}


function trackingToneClass(tracking) {
  const tone = String(tracking?.tone || tracking?.trend || '').toLowerCase();
  if (tone.includes('hot')) return 'trend-hot';
  if (tone.includes('cold')) return 'trend-cold';
  return 'trend-neutral';
}

function trackingLabel(tracking) {
  if (!tracking) return 'No tracking yet';
  return tracking.label || `${tracking.record || '0-0'} ${tracking.pctText || ''}`.trim() || 'No tracking yet';
}

function trackingTrendText(tracking) {
  if (!tracking) return 'Limited';
  return tracking.trend || 'Limited';
}

function cardProbabilityHtml(card) {
  const prob = coerceProbability(card?.probability);
  if (!Number.isFinite(prob)) {
    if (hasNumericValue(card?.model)) return `<span class="pick-prob-label">Model</span><strong>${escapeHtml(fmt(card.model, 1))}</strong>`;
    return `<span class="pick-prob-label">Signal</span><strong>Model</strong>`;
  }
  return `<span class="pick-prob-label">Probability</span><strong>${escapeHtml(fmtPct(prob, 0))}</strong>`;
}

function isTopPitcherProp(card) {
  const stat = String(card?.stat || '').toUpperCase();
  const category = String(card?.category || card?.title || '').toLowerCase();
  return stat === 'HA' || stat === 'ER' || (stat === 'K' && (category.includes('pitcher') || category.includes('sp')));
}

function topPickPrimaryBaseline(card) {
  if (!isTopPitcherProp(card)) return null;
  return hasNumericValue(card?.average) ? `Avg ${fmt(card.average, 1)}` : null;
}

function topPickCardHtml(card) {
  const tracking = card?.tracking || {};
  const toneClass = trackingToneClass(tracking);
  const matchup = card?.matchup || [card?.team, card?.opp ? `vs ${card.opp}` : ''].filter(Boolean).join(' ');
  const detailBits = [];
  const baseline = topPickPrimaryBaseline(card);
  if (baseline) detailBits.push(baseline);
  else if (hasNumericValue(card?.line)) detailBits.push(`Line ${fmt(card.line, 1)}`);
  if (hasNumericValue(card?.model)) detailBits.push(`Model ${fmt(card.model, 1)}`);
  if (!baseline && hasNumericValue(card?.average)) detailBits.push(`Avg ${fmt(card.average, 1)}`);
  if (hasNumericValue(card?.modelTotal)) detailBits.push(`Model total ${fmt(card.modelTotal, 1)}`);
  const detailHtml = detailBits.length
    ? `<div class="mini-chip-row">${detailBits.map(bit => `<span class="mini-chip">${escapeHtml(bit)}</span>`).join('')}</div>`
    : '';
  const href = card?.href || '#';
  return `
    <article class="top-pick-card ${toneClass}">
      <div class="top-pick-head">
        <span class="tag">${escapeHtml(card?.league || '')}</span>
        <span class="trend-pill ${toneClass}">${escapeHtml(trackingTrendText(tracking))}</span>
      </div>
      <p class="top-pick-category">${escapeHtml(card?.category || card?.title || 'Model pick')}</p>
      <h3>${escapeHtml(card?.pick || card?.title || 'Model signal')}</h3>
      <p class="muted top-pick-matchup">${escapeHtml(matchup || 'Today')}</p>
      <div class="top-pick-metric">${cardProbabilityHtml(card)}</div>
      ${detailHtml}
      <div class="tracking-strip ${toneClass}">
        <span>${escapeHtml(tracking?.scope || 'Recent category')}</span>
        <strong>${escapeHtml(trackingLabel(tracking))}</strong>
      </div>
      <p class="insight-copy">${escapeHtml(card?.reason || 'Model signal from today’s slate.')}</p>
      <a class="button-link button-link-subtle top-pick-link" href="${escapeHtml(href)}">Analyze</a>
    </article>
  `;
}

function renderTopPickPulse(homeTopPicks) {
  const root = byId('home-top-picks-pulse');
  if (!root) return;
  const tracking = homeTopPicks?.trackingSummary || {};
  const propTrackers = Object.entries(tracking?.props || {}).map(([key, value]) => ({ key, ...value }));
  const gameTrackers = Object.entries(tracking?.games || {}).map(([key, value]) => ({ key, ...value }));
  const rows = [...propTrackers, ...gameTrackers]
    .filter(row => row && (row.sample || row.record))
    .slice(0, 7);
  if (!rows.length) {
    root.innerHTML = '<div class="empty-state">No recent top-pick tracking available yet.</div>';
    return;
  }
  root.innerHTML = rows.map(row => `
    <article class="pulse-card ${trackingToneClass(row)}">
      <span>${escapeHtml(row.scope || row.key || 'Category')}</span>
      <strong>${escapeHtml(row.record || '0-0')}</strong>
      <small>${escapeHtml(row.pctText || '—')} • ${escapeHtml(row.trend || 'Limited')}</small>
    </article>
  `).join('');
}

function renderHomeTopPicks(homeTopPicks) {
  const root = byId('home-top-picks-grid');
  if (!root) return;
  const cards = Array.isArray(homeTopPicks?.topCards) ? homeTopPicks.topCards : [];
  setText('hero-top-pick-count', String(cards.length));
  if (!cards.length) {
    root.innerHTML = '<div class="empty-state">No featured top picks are available yet. Run tools/build_home_top_picks_json.py after today’s data is generated.</div>';
    return;
  }
  root.innerHTML = cards.map(topPickCardHtml).join('');
}

function compactPickRowHtml(card, options = {}) {
  const prob = coerceProbability(card?.probability);
  const probText = Number.isFinite(prob) ? fmtPct(prob, 0) : (hasNumericValue(card?.model) ? `Model ${fmt(card.model, 1)}` : 'Model');
  const metricValue = options.metric === 'average'
    ? (hasNumericValue(card?.average) ? fmt(card.average, 1) : '—')
    : (card?.line !== null && card?.line !== undefined && card?.line !== '' ? fmt(card.line, 1) : '—');
  return `
    <tr>
      <td><a class="table-link" href="${escapeHtml(card?.href || '#')}">${escapeHtml(card?.player || card?.pick || '')}</a></td>
      <td>${escapeHtml(metricValue)}</td>
      <td>${escapeHtml(hasNumericValue(card?.model) ? fmt(card.model, 1) : '—')}</td>
      ${options.showSeparateAverage ? `<td>${escapeHtml(hasNumericValue(card?.average) ? fmt(card.average, 1) : '—')}</td>` : ''}
      <td>${escapeHtml(probText)}</td>
      <td>${escapeHtml(card?.matchup || '')}</td>
    </tr>
  `;
}

function mlbBoardSnapshotTable(title, rows, options = {}) {
  const safeRows = Array.isArray(rows) ? rows : [];
  const metric = options.metric || 'line';
  const metricLabel = options.metricLabel || (metric === 'average' ? 'Avg.' : 'Line');
  const showSeparateAverage = Boolean(options.showSeparateAverage);
  if (!safeRows.length) {
    return `<article class="insight-board"><h4>${escapeHtml(title)}</h4><div class="empty-state">No entries available yet.</div></article>`;
  }
  return `
    <article class="insight-board">
      <h4>${escapeHtml(title)}</h4>
      <div class="table-wrap compact-table-wrap">
        <table class="compact-table">
          <thead><tr><th>Player</th><th>${escapeHtml(metricLabel)}</th><th>Model</th>${showSeparateAverage ? '<th>Avg.</th>' : ''}<th>Prob.</th><th>Matchup</th></tr></thead>
          <tbody>${safeRows.map(card => compactPickRowHtml(card, { metric, showSeparateAverage })).join('')}</tbody>
        </table>
      </div>
    </article>
  `;
}

function renderMlbHomeBoardsSnapshot(homeTopPicks) {
  const root = byId('mlb-home-props-grid');
  const tabs = byId('mlb-board-tabs');
  if (!root) return;
  const boards = homeTopPicks?.mlbBoards || {};
  const config = [
    { key: 'hits', label: 'Hits', options: { metric: 'line', metricLabel: 'Line', showSeparateAverage: true } },
    { key: 'hrr', label: 'HRR', options: { metric: 'line', metricLabel: 'Line', showSeparateAverage: true } },
    { key: 'totalBases', label: '1.5+ Total Bases', options: { metric: 'line', metricLabel: 'Line', showSeparateAverage: true } },
    { key: 'pitcherKs', label: 'Pitcher Ks', options: { metric: 'average', metricLabel: 'Avg.' } },
    { key: 'pitcherHA', label: 'Pitcher Hits Allowed', options: { metric: 'average', metricLabel: 'Avg.' } },
    { key: 'pitcherERLow', label: 'Lowest SP ER', options: { metric: 'average', metricLabel: 'Avg.' } },
    { key: 'pitcherERHigh', label: 'Highest SP ER', options: { metric: 'average', metricLabel: 'Avg.' } }
  ];
  const available = config.filter(item => Array.isArray(boards[item.key]) && boards[item.key].length);
  if (!available.length) {
    root.innerHTML = '<div class="empty-state">No MLB quick boards available yet.</div>';
    if (tabs) tabs.innerHTML = '';
    return;
  }

  const renderBoard = key => {
    const item = config.find(entry => entry.key === key) || available[0];
    root.innerHTML = mlbBoardSnapshotTable(item.label, boards[item.key] || [], item.options || {});
    if (tabs) {
      [...tabs.querySelectorAll('button')].forEach(btn => btn.classList.toggle('active', btn.dataset.board === item.key));
    }
  };

  if (tabs && !tabs.dataset.bound) {
    tabs.innerHTML = available.map(item => `<button type="button" data-board="${escapeHtml(item.key)}">${escapeHtml(item.label)}</button>`).join('');
    tabs.addEventListener('click', event => {
      const button = event.target.closest('button[data-board]');
      if (!button) return;
      renderBoard(button.dataset.board);
    });
    tabs.dataset.bound = '1';
  }
  renderBoard(available[0].key);
}

function quickGameCardHtml(item) {
  const prob = coerceProbability(item?.probability);
  return `
    <article class="quick-game-card">
      <div class="quick-game-top">
        <span class="tag">${escapeHtml(item?.league || '')}</span>
        <strong>${escapeHtml(Number.isFinite(prob) ? fmtPct(prob, 0) : 'Model')}</strong>
      </div>
      <h3>${escapeHtml(item?.pick || 'Game signal')}</h3>
      <p class="muted">${escapeHtml(item?.matchup || '')}</p>
      <p>${escapeHtml(item?.modelScore || item?.reason || '')}</p>
      <a class="table-link" href="${escapeHtml(item?.href || '#')}">Open game detail</a>
    </article>
  `;
}

function renderHighConfidenceGames(homeTopPicks, fallbackGames, meta) {
  const root = byId('high-confidence-games-grid');
  if (!root) return;
  const cards = Array.isArray(homeTopPicks?.highConfidenceGames) ? homeTopPicks.highConfidenceGames : [];
  if (cards.length) {
    root.innerHTML = cards.slice(0, 8).map(quickGameCardHtml).join('');
    return;
  }
  const today = (fallbackGames || []).filter(g => g.gameDate === meta?.targetDate)
    .map(g => ({
      league: g.league,
      matchup: `${g.awayTeam} @ ${g.homeTeam}`,
      pick: g.favoriteWinLabel || 'Game lean',
      probability: g.favoriteWinProb,
      modelScore: `${fmt(g.modelAwayScore, 1)} - ${fmt(g.modelHomeScore, 1)}`,
      href: `game.html?id=${encodeURIComponent(g.id)}`,
      reason: g.summary || ''
    }))
    .sort((a, b) => coerceProbability(b.probability) - coerceProbability(a.probability))
    .slice(0, 8);
  root.innerHTML = today.length ? today.map(quickGameCardHtml).join('') : '<div class="empty-state">No high-confidence games available yet.</div>';
}

function parlayItemKey(item) {
  return [item?.gameId || item?.id || item?.matchup || '', item?.player || '', item?.stat || item?.pick || ''].join('|');
}

function parlayGameKey(item) {
  return String(item?.gameId || item?.matchup || item?.id || '').trim();
}

function parlayConflict(a, b) {
  const samePlayer = normalizeLookupToken(a?.player || '') && normalizeLookupToken(a?.player || '') === normalizeLookupToken(b?.player || '');
  if (!samePlayer) return false;
  const statA = String(a?.stat || '').toUpperCase();
  const statB = String(b?.stat || '').toUpperCase();
  return statA && statB && statA === statB;
}

function parlayBaseThreshold(style) {
  if (style === 'safe') return 0.62;
  if (style === 'upside') return 0.52;
  return 0.56;
}

function parlayCandidateWeight(item, style, minProb) {
  const probability = coerceProbability(item?.probability);
  if (!Number.isFinite(probability)) return 0;
  const lift = Math.max(0.015, probability - minProb + 0.04);
  const exponent = style === 'safe' ? 3.25 : style === 'upside' ? 1.45 : 2.2;
  const categoryBonus = String(item?.type || '').toLowerCase() === 'game' ? 0.92 : 1;
  const trackingRate = coerceProbability(item?.tracking?.winRate);
  const trackingBonus = Number.isFinite(trackingRate) ? Math.max(0.82, Math.min(1.18, 0.92 + trackingRate * 0.35)) : 1;
  return Math.pow(lift, exponent) * categoryBonus * trackingBonus;
}

function weightedPick(items, style, minProb) {
  if (!items.length) return null;
  const weights = items.map(item => parlayCandidateWeight(item, style, minProb));
  const total = weights.reduce((sum, weight) => sum + weight, 0);
  if (!Number.isFinite(total) || total <= 0) return items[Math.floor(Math.random() * items.length)];
  let draw = Math.random() * total;
  for (let i = 0; i < items.length; i += 1) {
    draw -= weights[i];
    if (draw <= 0) return items[i];
  }
  return items[items.length - 1];
}

function filterParlayCandidates(pool, { sport, style, minProb }) {
  let candidates = (pool || [])
    .map(item => ({ ...item, probability: coerceProbability(item?.probability) }))
    .filter(item => Number.isFinite(item.probability) && item.probability >= minProb);
  if (sport && sport !== 'ALL') candidates = candidates.filter(item => String(item.league || '').toUpperCase() === sport);
  candidates.sort((a, b) => b.probability - a.probability);
  return candidates;
}

function sameGameParlayCandidates(candidates, count) {
  const groups = new Map();
  candidates.forEach(item => {
    const key = parlayGameKey(item);
    if (!key) return;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(item);
  });
  const eligible = Array.from(groups.values()).filter(group => group.length >= Math.min(count, 2));
  if (!eligible.length) return [];
  eligible.sort((a, b) => {
    const avgB = b.reduce((sum, item) => sum + item.probability, 0) / b.length;
    const avgA = a.reduce((sum, item) => sum + item.probability, 0) / a.length;
    return avgB - avgA;
  });
  const topGroups = eligible.slice(0, Math.min(8, eligible.length));
  return topGroups[Math.floor(Math.random() * topGroups.length)] || [];
}

function selectParlayLegs(pool, { count, sport, style, correlationMode }) {
  const baseMinProb = parlayBaseThreshold(style);
  const thresholds = [baseMinProb, Math.max(0.50, baseMinProb - 0.04), Math.max(0.48, baseMinProb - 0.08)];
  let bestSelection = [];

  for (const minProb of thresholds) {
    const candidates = filterParlayCandidates(pool, { sport, style, minProb });
    const workingPool = correlationMode === 'same-game' ? sameGameParlayCandidates(candidates, count) : candidates;
    if (!workingPool.length) continue;

    for (let attempt = 0; attempt < 45; attempt += 1) {
      const selected = [];
      const seen = new Set();
      const usedGames = new Map();
      const usedCategories = new Map();
      let available = workingPool.slice();

      while (available.length && selected.length < count) {
        const valid = available.filter(item => {
          const key = parlayItemKey(item);
          if (seen.has(key)) return false;
          if (selected.some(existing => parlayConflict(existing, item))) return false;
          const gameKey = parlayGameKey(item);
          const category = String(item.category || item.stat || item.type || '').toUpperCase();
          if (correlationMode === 'avoid' && gameKey && usedGames.has(gameKey)) return false;
          if (correlationMode === 'allow' && gameKey && (usedGames.get(gameKey) || 0) >= 2) return false;
          if (correlationMode !== 'same-game' && category && (usedCategories.get(category) || 0) >= 2) return false;
          return true;
        });
        if (!valid.length) break;
        const choice = weightedPick(valid, style, minProb);
        if (!choice) break;
        selected.push(choice);
        seen.add(parlayItemKey(choice));
        const gameKey = parlayGameKey(choice);
        if (gameKey) usedGames.set(gameKey, (usedGames.get(gameKey) || 0) + 1);
        const category = String(choice.category || choice.stat || choice.type || '').toUpperCase();
        if (category) usedCategories.set(category, (usedCategories.get(category) || 0) + 1);
        available = available.filter(item => parlayItemKey(item) !== parlayItemKey(choice));
      }

      if (selected.length > bestSelection.length) bestSelection = selected;
      if (selected.length >= count) return selected;
    }
  }

  return bestSelection;
}

function adjustedParlayProbability(legs, correlationMode) {
  if (!legs.length) return NaN;
  const raw = legs.reduce((acc, leg) => acc * coerceProbability(leg.probability), 1);
  const gameCounts = new Map();
  legs.forEach(leg => {
    const key = parlayGameKey(leg);
    if (!key) return;
    gameCounts.set(key, (gameCounts.get(key) || 0) + 1);
  });
  let penalty = correlationMode === 'same-game' ? 0.80 : 0.96;
  gameCounts.forEach(count => {
    if (count > 1) penalty *= Math.pow(0.86, count - 1);
  });
  return raw * penalty;
}

function renderParlayBuilder(homeTopPicks) {
  const output = byId('parlay-builder-output');
  if (!output) return;
  const pool = Array.isArray(homeTopPicks?.parlayPool) ? homeTopPicks.parlayPool : [];
  const controls = {
    count: byId('parlay-leg-count'),
    sport: byId('parlay-sport-filter'),
    style: byId('parlay-risk-style'),
    correlationMode: byId('parlay-correlation-mode'),
    reroll: byId('parlay-reroll'),
  };

  const rerender = () => {
    const count = Number(controls.count?.value || 3);
    const sport = controls.sport?.value || 'ALL';
    const style = controls.style?.value || 'balanced';
    const correlationMode = controls.correlationMode?.value || 'avoid';
    const minProb = parlayBaseThreshold(style);
    const matchingCandidates = filterParlayCandidates(pool, { sport, style, minProb });
    const legs = selectParlayLegs(pool, { count, sport, style, correlationMode });
    if (!legs.length) {
      output.innerHTML = '<div class="empty-state">No parlay candidates match those filters yet.</div>';
      return;
    }
    const estimate = adjustedParlayProbability(legs, correlationMode);
    const sportLabel = sport === 'ALL' ? 'mixed-sport' : sport;
    output.innerHTML = `
      <article class="parlay-card">
        <div class="parlay-card-head">
          <div>
            <p class="eyebrow">Generated card</p>
            <h3>${legs.length}-pick ${style === 'safe' ? 'safer' : style === 'upside' ? 'upside' : 'balanced'} ${sportLabel} card</h3>
            <p class="muted">Pool: ${escapeHtml(String(matchingCandidates.length))} candidates. Generate again for a new weighted combination.</p>
          </div>
          <div class="parlay-prob"><span>Est. probability</span><strong>${escapeHtml(Number.isFinite(estimate) ? fmtPct(estimate, 1) : 'N/A')}</strong></div>
        </div>
        <ol class="parlay-leg-list">
          ${legs.map(leg => `
            <li>
              <div>
                <strong>${escapeHtml(leg.pick || leg.title || '')}</strong>
                <span>${escapeHtml([leg.league, leg.matchup || leg.category].filter(Boolean).join(' • '))}</span>
              </div>
              <a href="${escapeHtml(leg.href || '#')}">${escapeHtml(fmtPct(leg.probability, 0))}</a>
            </li>
          `).join('')}
        </ol>
        <p class="muted">This uses weighted random selection from higher-probability model picks, then excludes duplicate/conflicting legs and applies a conservative correlation penalty.</p>
      </article>
    `;
  };

  Object.values(controls).forEach(control => {
    if (control && !control.dataset.bound) {
      control.addEventListener(control.tagName === 'BUTTON' ? 'click' : 'change', rerender);
      control.dataset.bound = '1';
    }
  });
  rerender();
}

function fillHeader(meta, todayGames, tomorrowGames, props) {
  setText('site-title', meta?.siteTitle && meta.siteTitle !== 'Sports Predictions Showcase' ? meta.siteTitle : 'Lets Parlay ML');
  setText('hero-leagues', Array.isArray(meta?.leagues) ? meta.leagues.join(' • ') : 'NBA • MLB • NHL');
  setText('hero-game-count', String((todayGames || []).length));
  setText('hero-next-game-count', String((tomorrowGames || []).length));
  setText('hero-prop-count', String((props || []).length));
  setText('hero-updated', meta?.lastUpdated || '—');
  setText('today-date-label', meta?.targetDate || '');
  setText('today-date-label-full', meta?.targetDate || '');
  setText('tomorrow-date-label', meta?.nextDate || '');
  setText('results-date-label', meta?.resultsDate || meta?.targetDate || '');
}

function setupLeagueFilter(allGames, meta) {
  const select = byId('league-filter');
  if (!select) return;
  uniqueLeagues(allGames).forEach(league => {
    const option = document.createElement('option');
    option.value = league;
    option.textContent = league;
    select.appendChild(option);
  });
  const rerender = () => {
    const league = select.value;
    const today = (allGames || []).filter(g => g.gameDate === meta.targetDate);
    const tomorrow = (allGames || []).filter(g => g.gameDate === meta.nextDate);
    renderGameSection(today, 'today-games-grid', league);
    renderGameSection(tomorrow, 'tomorrow-games-grid', league);
  };
  select.addEventListener('change', rerender);
  rerender();
}

(async function init() {
  const root = byId('today-games-grid') || byId('games-grid');
  try {
    const [meta, games, rawProps, rawPropsLab, results, resultsSummary, resultsHistory, rawHomeInsights, injuries, mlbPropResults, mlbPropSummary, mlbPropPending, homeTopPicks, mlbResultsLaunchText] = await Promise.all([
      loadJson('data/site.json'),
      loadJson('data/games.json', []),
      loadJson('data/props.json', []),
      loadJson('data/nba_props_lab.json', null),
      loadJson('data/results.json', []),
      loadJson('data/results_summary.json', {}),
      loadJson('data/results_history.json', []),
      loadJson('data/nba_home_insights.json', {}),
      loadJson('data/nba_injuries.json', {}),
      loadJson('data/mlb_prop_results_history.json', []),
      loadJson('data/mlb_prop_results_summary.json', {}),
      loadJson('data/mlb_prop_results_pending.json', []),
      loadJson('data/home_top_picks.json', {}),
      loadText('data/mlb_results_launch_date.txt', '')
    ]);
    const injuryLookup = buildInjuryLookup(injuries);
    const gameLookup = buildGameLookup(games);

    const propsSource = flattenPropsSource(rawPropsLab);
    const baseProps = propsSource.length ? propsSource : rawProps;

    const props = applyInjuryContextToList(baseProps, injuryLookup)
      .map(prop => enrichHomepageProp(prop, gameLookup));

    const hasDatedProps = props.some(p => propDateValue(p));

    const todayPool = hasDatedProps
      ? props.filter(p => propDateValue(p) === meta.targetDate)
      : props;

    const nextPool = hasDatedProps
      ? props.filter(p => propDateValue(p) === meta.nextDate)
      : [];

const todayProps = selectHomepageTopProps(todayPool, 12);
const nextProps = selectHomepageTopProps(nextPool, 10);
    const homeInsights = applyInjuryContextToHomeInsights(rawHomeInsights, injuryLookup);
    const todayGames = (games || []).filter(g => g.gameDate === meta.targetDate);
    const tomorrowGames = (games || []).filter(g => g.gameDate === meta.nextDate);
    fillHeader(meta, todayGames, tomorrowGames, todayProps);
    setupLeagueFilter(games, meta);
    renderProps(todayProps, 'props-body');
    renderProps(nextProps, 'props-next-body');
    renderTopPickPulse(homeTopPicks);
    renderHomeTopPicks(homeTopPicks);
    renderParlayBuilder(homeTopPicks);
    renderMlbHomeBoardsSnapshot(homeTopPicks);
    renderHighConfidenceGames(homeTopPicks, games, meta);
    renderNbaGameEdges(games, meta);
    renderHomeInsights(homeInsights, meta);
    const mlbResultsLaunchDate = String(mlbResultsLaunchText || '').trim();
    const filteredResults = filterResultsForLaunch(results, mlbResultsLaunchDate);
    const filteredHistory = filterResultsForLaunch(resultsHistory, mlbResultsLaunchDate);
    const effectiveSummary = recomputeResultsSummaryFromHistory(filteredHistory, resultsSummary);

    renderResultsSummary(effectiveSummary);
    setupResultsExplorer(filteredResults, filteredHistory, meta?.resultsDate || '');

    const trackedMlbPropResults = filterMlbTrackedHomeBoardRows(mlbPropResults);
    const trackedMlbPropPending = filterMlbTrackedHomeBoardRows(mlbPropPending);
    const trackedMlbPropSummary = buildMlbPropSummaryFromRows(trackedMlbPropResults, mlbPropSummary);
    renderMlbPropResultsSummary(trackedMlbPropSummary, trackedMlbPropPending);
    setupMlbPropResultsExplorer(trackedMlbPropResults, trackedMlbPropSummary, trackedMlbPropPending);
  } catch (err) {
    console.error(err);
    if (root) root.innerHTML = `<div class="empty-state">Failed to load site data: ${escapeHtml(err.message || err)}</div>`;
  }
})();